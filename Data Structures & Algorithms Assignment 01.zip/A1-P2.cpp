#include <iostream>
#include <vector>
#include <memory>
#include <cstdint>
#include <string>
#include <cstdlib>
#include <ctime>

using namespace std;

struct Node {
    uint64_t value;
    Node* next;
    Node(uint64_t val) : value(val), next(nullptr) {}
};

class LinkedList {
public:
    Node* head;

    LinkedList() : head(nullptr) {}

    void addNode(uint64_t num) {
        Node* newNode = new Node(num);
        if (!head) {
            head = newNode;
        } else {
            Node* temp = head;
            while (temp->next) {
                temp = temp->next;
            }
            temp->next = newNode;
        }
    }

    void printList() {
        Node* temp = head;
        while (temp) {
            cout << temp->value << " ";
            temp = temp->next;
        }
        cout << endl;
    }
};

// Modular exponentiation function (a^b % mod)
uint64_t modExp(uint64_t base, uint64_t exp, uint64_t mod) {
    uint64_t result = 1;
    while (exp > 0) {
        if (exp % 2 == 1) {
            result = (result * base) % mod;
        }
        base = (base * base) % mod;
        exp /= 2;
    }
    return result;
}

// Function to multiply two large numbers represented in linked list
// Result will be stored in a modulo format since we can't store large numbers directly
uint64_t modLinkedList(LinkedList& num, uint64_t mod) {
    Node* temp = num.head;
    uint64_t result = 0;
    while (temp) {
        result = (result * 1000000000000000000ULL + temp->value) % mod;
        temp = temp->next;
    }
    return result;
}

// Function to perform Miller-Rabin test on large number in linked list
bool millerRabinTest(LinkedList& num, int iterations) {
    const vector<uint64_t> smallPrimes = {2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47};
    
    // If number is divisible by small primes, it's not prime
    for (uint64_t prime : smallPrimes) {
        if (modLinkedList(num, prime) == 0) return false;
    }

    // Perform Miller-Rabin test using base values
    uint64_t numMinus1 = modLinkedList(num, UINT64_MAX);  // num - 1
    uint64_t d = numMinus1;
    int r = 0;

    // Find r and d such that num - 1 = d * 2^r
    while (d % 2 == 0) {
        d /= 2;
        r++;
    }

    // Miller-Rabin Test
    for (int i = 0; i < iterations; i++) {
        uint64_t a = 2 + rand() % (numMinus1 - 2);
        uint64_t x = modExp(a, d, numMinus1);

        if (x == 1 || x == numMinus1) continue;

        bool isComposite = true;
        for (int j = 0; j < r - 1; j++) {
            x = modExp(x, 2, numMinus1);
            if (x == numMinus1) {
                isComposite = false;
                break;
            }
        }

        if (isComposite) return false;
    }
    return true;
}

int main() {
    srand(static_cast<unsigned int>(time(0)));

    string largeNumber;
    cout << "Enter a 1024-bit number: ";
    cin >> largeNumber;

    LinkedList largeNumList;
    for (int i = largeNumber.length(); i > 0; i -= 18) {
        uint64_t chunk = stoull(largeNumber.substr(max(0, i - 18), min(18, i)));
        largeNumList.addNode(chunk);
    }

    cout << "Linked list representation: ";
    largeNumList.printList();

    int iterations = 5;
    bool isPrime = millerRabinTest(largeNumList, iterations);

    cout << "Input: " << largeNumber << endl;
    cout << "Output: " << (isPrime ? "True" : "False") << endl;

    return 0;
}