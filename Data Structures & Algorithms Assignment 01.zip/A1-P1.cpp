#include <iostream>
using namespace std;

// Define a Process Node structure
class ProcessNode {
public:
    int process_id;
    int execution_time;
    int remaining_time;
    ProcessNode* next;

    ProcessNode(int id, int exec_time) {
        process_id = id;
        execution_time = exec_time;
        remaining_time = exec_time;
        next = nullptr;
    }
};

// Circular Linked List for CPU Scheduling
class CircularLinkedList {
private:
    ProcessNode* head;
    ProcessNode* tail;

public:
    CircularLinkedList() {
        head = nullptr;
        tail = nullptr;
    }

    // Add a new process to the list
    void addProcess(int process_id, int exec_time) {
        ProcessNode* newNode = new ProcessNode(process_id, exec_time);
        if (!head) {
            head = newNode;
            tail = newNode;
            tail->next = head;
        } else {
            tail->next = newNode;
            tail = newNode;
            tail->next = head;
        }
    }

    // Remove a process from the list once it completes
    void removeProcess(ProcessNode* target) {
        if (!head) return;

        if (head == tail && head == target) {  // Only one process
            delete head;
            head = nullptr;
            tail = nullptr;
        } else {
            ProcessNode* temp = head;
            ProcessNode* prev = nullptr;

            do {
                if (temp == target) {
                    if (temp == head) {
                        head = head->next;
                        tail->next = head;
                    } else if (temp == tail) {
                        tail = prev;
                        tail->next = head;
                    } else {
                        prev->next = temp->next;
                    }
                    delete temp;
                    break;
                }
                prev = temp;
                temp = temp->next;
            } while (temp != head);
        }
    }

    // Run CPU scheduling algorithm
    void runScheduler(int cpu_time_per_cycle) {
        if (!head) {
            cout << "No processes to schedule." << endl;
            return;
        }

        ProcessNode* current = head;
        int cycle = 1;

        while (head) {
            cout << "Cycle " << cycle++ << ": " << endl;
            ProcessNode* next = current->next;

            // Process each node
            if (current->remaining_time <= cpu_time_per_cycle) {
                cout << "Process " << current->process_id << " (Remaining: 0)" << endl;
                removeProcess(current);
            } else {
                current->remaining_time -= cpu_time_per_cycle;
                cout << "Process " << current->process_id << " (Remaining: " << current->remaining_time << ")" << endl;
            }

            current = next;
            if (!head) break;  // If no processes are left
            cout << endl;
        }
    }
};

int main() {
    CircularLinkedList scheduler;

    // Adding processes
    scheduler.addProcess(1, 10);
    scheduler.addProcess(2, 5);
    scheduler.addProcess(3, 8);

    // Run the scheduler with 3 units of CPU time per process
    scheduler.runScheduler(3);

    return 0;
}
